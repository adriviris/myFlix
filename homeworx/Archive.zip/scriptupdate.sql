UPDATE Users
    SET Email='lizzimcguire@gmeil.com'
    WHERE username = 'Lizzie'