DELETE FROM Movies
    WHERE MovieID = 1;